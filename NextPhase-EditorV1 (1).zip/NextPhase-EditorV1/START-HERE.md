# NextPhase Editor V1 — the documentary edit, as a Claude Code skill

Hand Claude a plain talking-head recording. It finds the real evidence for every line you say
online, re-colours it, and cuts it into a fast documentary edit, rendered on your own computer.

## What it makes

- **A new picture every 0.6–1.5 seconds**, and almost every one is real: the company's own
  pages, posts and launch films, public-domain archive footage, NASA and Wikimedia images,
  rebuilt app screens fed with real data. A metaphor or a pun wherever the line allows it.
- **Every found image re-coloured**: teal split, hard black and white, amber, negative flashes,
  targeted recolours. Your own face stays raw and natural.
- **Named devices, measured frame by frame** off three documentary reels: tile-flash reveals on
  a thirds grid, you cut out in front of a world that changes behind you with a huge red word
  behind your head, cards popping one per word, a 3D wall of cards, shape-matched 2-frame
  strobes, datamoshes, and the video showing its own timeline and code.
- **Sound on every change**: a click per pop, pane and strobe image, hits and glitches, all placed
  by the devices themselves, and a music bed that cuts out under your punchline.
- **Free.** The open-source HyperFrames renderer, ffmpeg and Python, all on your machine. No API
  keys, no credits, no watermark.

## What you need

- **Claude Code**
- **macOS or Linux** (Windows: inside WSL). Apple Silicon is fastest (on-device speech model).
- **Node.js 22+, ffmpeg, Python 3.9+**: the setup checks these and tells Claude how to install
  anything missing, the free official way. **Google Chrome** for capturing web pages.
- About 2 GB of free disk (renderer, its browser, speech model), plus about 1 GB if you turn on
  the cut-out device (PyTorch)
- A 16:9 talking-head recording

## Install (about 5–10 minutes)

1. **Download** `NextPhase-EditorV1.zip` and leave it in Downloads.
2. **Open Claude Code** in any folder.
3. **Paste all of `SETUP-PROMPT.txt`** and press Enter.

Claude installs the skill, sets up the free tools, asks whether you want the cut-out device
(a 1 GB one-time download), and renders a 7-second test video to prove it works. Start a new Claude Code session afterwards so the skill
loads.

## Then use it

- "Edit ~/Desktop/my-video.mov with editor-v1"
- "Edit my latest recording in the editor v1 style, the bed is ~/Music/track.mp3"

Claude transcribes the take, finds material for every line, and **shows you the plan (every
line, its picture, its source and licence) before it builds**. Then it renders, mixes and opens
`out/final.mp4` for you to review. It never posts or uploads anything.

## Bring your own

- **Music.** None ships. Use a track you have the rights to.
- **Rights to what Claude finds.** It flags anything unclear (a company's own film, a news photo,
  someone else's clip) in the plan; the final call on what goes in a published video is yours.

See `LICENSE-NOTES.md` for what is inside and under which licence.
